﻿using PersonNP;

namespace IPersonFactoryNP
{
    public interface IPersonFactory
    {
        People CreatePerson();
    }
}