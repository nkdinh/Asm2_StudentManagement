﻿namespace PersonNP
{
    public abstract class People
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }

}